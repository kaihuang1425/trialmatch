# TrialMatch 3D protein view: handoff

TrialMatch matches lung cancer (NSCLC) patients to recruiting trials. This package is the 3D part. A clinician opens a patient and sees their driver protein in 3D: the changed residue is lit in coral, and a drug that targets it sits in its pocket in teal. The point is to show "what's at fault" and why a targeted trial fits.

The next step, a zoom from the human body to the lungs to the protein, is specified in `ZOOM-JOURNEY-SPEC.md` and not started.

Snapshot taken 7 Nov 2026, about 19:05, while the module was still being built. The 3D view works (see `screenshots/`), but some pieces listed under "Not done" are missing.

## Open it

No install, no server, no internet. Double-click either page:

- `app/preview.html`: a simple picker. Choose a patient and a trial, then press **See the change**. It opens on the KRAS G12C case.
- `app/protein-demo.html`: the fuller demo page, still in progress.

In the sheet:
- drag to rotate, scroll or pinch to zoom;
- "The change | The drug" switches between the fault and the drug;
- Esc closes.

Tested in Chromium-based browsers only.

## Files

| Path | What |
|---|---|
| `app/protein/protein-view.js` | The module, about 57 KB. Self-contained: it injects its own CSS, and every class uses the prefix `pv-`. |
| `app/protein/structures.js` | 11 trimmed crystal structures plus facts per entry, as `window.TM_STRUCTURES`. 1.35 MB. Generated; don't edit by hand. |
| `app/vendor/3Dmol-min.js` | 3Dmol.js 2.5.5, the renderer (BSD-3, licence alongside). |
| `app/preview.html`, `app/preview-data.js` | Picker page and its data: 4 demo records, 1 synthetic record, 3 trials. |
| `app/protein-demo.html` | The builder's demo page (in progress). |
| `tools/prepare_structures.py` | Downloads each entry from files.rcsb.org, trims it to the protein chain and the drug, and rewrites `structures.js`. Needs internet. Run `python tools/prepare_structures.py` from the package root; it refuses to write over the 1.5 MB budget. |
| `research/3d-viewer-research.md` | Library and model options, licences, PDB facts, prior art (cBioPortal, COSMIC-3D, BodyMapR), and what was not verified. |
| `screenshots/` | The view running: KRAS G12C, EGFR exon 19 deletion, BRAF V600E. |

## API

```html
<script src="protein/protein-view.js"></script>   <!-- small; loads 3Dmol and the structures only on first open -->
```

```js
TMProtein.open({ record, trial, theme: 'dark' | 'light' | 'auto', opener });  // opens the sheet
TMProtein.resolve(record, trial);  // what would be shown, as plain data (good for tests)
TMProtein.close();
```

- **`record`** has the same shape as the app's demo records: `{ id, biomarkers, evidence, ... }`.
  - `biomarkers` keys: `EGFR`, `EGFR_type`, `KRAS_G12C`, `KRAS_G12D`, `BRAF_V600E`, `ALK`, `ROS1`, `RET`, `MET_ex14`.
  - Values: `positive`, `negative` or `unknown`.
  - The exact EGFR change is read from `evidence.EGFR` (e.g. "EGFR: Exon 19 deletion (clinical test)").
- **`trial`** needs `title` and/or `short`, plus `interventions: [{ name, otherNames }]` or `drugs`. The module finds the drug by name.

A `TMProtein.mount(container, opts)` call, for embedding the view inside another page's stage, was requested but is not in this snapshot. The zoom journey needs it.

## What each case shows

The module picks the patient's positive driver. If the trial names a drug that has a structure for that driver, it shows that drug as "this trial's drug". Otherwise it shows the driver's default structure and says plainly that the drug is not the trial's.

| Driver | Default structure | Drug shown | Lit up |
|---|---|---|---|
| KRAS G12C | 6OIM (1.65 Å) | sotorasib. Trial drug overrides: adagrasib 6UT0, divarasib 9DMM, calderasib 8S8C | Cys12 |
| KRAS G12D | 9CTB (1.29 Å) | zoldonrasib, shown with cyclophilin A, the second protein it binds | Asp12 |
| EGFR | 6JWL (2.55 Å) | osimertinib | The patient's recorded change, e.g. Glu746–Ala750 for an exon 19 deletion. The caption says the crystal carries L858R, not this patient's change. |
| BRAF V600E | 3OG7 (2.45 Å) | vemurafenib, "same drug class as dabrafenib" when the trial uses dabrafenib | Glu600. The dabrafenib structure 4XV2 lacks residue 600, so it is not used. |
| ALK, ROS1, RET (fusions) | 4CLI lorlatinib, 3ZBF crizotinib, 7JU6 selpercatinib | as listed | The kinase domain. A fusion has no single changed residue. |
| MET exon 14 | 9SXJ (1.32 Å) | capmatinib | The kinase domain. The exon 14 region isn't in the crystal. |
| No positive driver | none | none | A calm "no driver change found" state, with tested-negative and not-tested chips |

All 11 PDB IDs were checked against RCSB on 7 Nov 2026 (title and resolution).

## Rules to keep (the project's honesty rule)

- Every view says: "Crystal structure from the Protein Data Bank (ID, resolution), not this patient's tumour." It adds the construct note when the protein was engineered.
- A drug is called "this trial's drug" only when the trial names it.
- Never imply a residue, site or drug the record doesn't support. Unknown looks different from negative.

## Not done

- No-WebGL fallback stills: the code expects `app/protein/fallback/*.png`, which don't exist yet.
- Phone width (390 px) and light theme weren't checked in this snapshot; dark at desktop width was.
- No automated tests for `resolve()` yet.
- `TMProtein.mount()` (see above).
- No public structure exists for zongertinib. Amivantamab isn't in the trial data.

## Wiring it into TrialMatch

The app is one offline page, `trialmatch/app/index.html`, built from `app/template.html`. Copy `app/protein/` and `app/vendor/` next to it. Add the script tag, then a "See the change" button on the clinician's patient view that calls:

```js
TMProtein.open({ record, trial, theme: 'dark', opener: button })
```

`<script src>` works when the page is opened as a file; fetch doesn't. That's why the structures ship as a `.js` file.

## Licences and data

- 3Dmol.js: BSD-3-Clause.
- Protein Data Bank entries: CC0. Cite the entries and wwPDB anyway.
- Demo records TCGA-*: de-identified public research records.
- `SYNTHETIC-KRAS` in `preview-data.js`: made up, for the preview only.
