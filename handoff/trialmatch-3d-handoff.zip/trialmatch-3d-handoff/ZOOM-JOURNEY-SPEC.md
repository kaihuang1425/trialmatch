# Zoom journey: body → lungs → protein

Not started. This is the spec.

## The idea

A clinician presses "See the change" on a patient. The camera starts on a human body, dollies into the lungs, then dives into the patient's driver protein, where the existing 3D protein view (`app/protein/`) takes over.

## Honesty limits (non-negotiable)

The records hold stage, histology, sex and `brain_mets`. They do not say which lung, which lobe, or where the cancer has spread.

- Never place a tumour on a specific side or lobe. Mark the whole lungs softly, with the label "side and lobe not recorded".
- Show the brain as involved only when `brain_mets` says so.
- Other metastatic sites appear as grey "?" (not recorded), never as lesions. Stage IV with no sites reads "spread, sites not recorded".
- A patient with no positive driver (e.g. TCGA-99-8033) stops at the lungs, with a calm "no driver change found" end state and no protein.
- Show the anatomy model's credit line as its licence requires.

## Models and licences

From `research/3d-viewer-research.md`:

- **HuBMAP HRA organ models:** CC BY 4.0. The male lung GLB is 10.9 MB, with every lobe and segment as a named node. No adrenal model; the lymph node model is one node, not body-wide stations.
- **BodyParts3D:** CC BY 4.0 on the current licence page (older releases said CC BY-SA 2.1 JP).
- **Z-Anatomy:** CC BY-SA 4.0, with some parts NC. Avoid it.
- **BioDigital:** commercial. Skip it.
- **Renderer:** use three.js (MIT). model-viewer can only change materials, so it can't colour single parts.
- A whole-body 3D model runs to 80+ MB. Keep the body light: a simplified mesh, or a stylised low-poly silhouette.

Not verified yet: loading a GLB from a data URI on file://, the size of a simplified lung GLB, and whether the HRA organ files share one coordinate frame.

## Hard constraints

- **Offline on file://.** The app opens by double-click, which blocks fetch/XHR. Every model must ship inside a `.js` file (e.g. a base64 GLB) and load lazily on first open. Avoid decoders that fetch wasm.
- Budget: 4 MB or less for all journey assets. Zero network requests.
- Use your own CSS prefix (e.g. `jv-`) and leave `app/protein/` untouched.
- Expose `window.TMJourney = { open({ record, trial, theme, opener }), close() }`.
- End the journey inside the protein view. Use `TMProtein.mount(container, opts)` if it exists by then; otherwise crossfade into `TMProtein.open(...)`.

## Design

- Clean and clinician-first. No helper paragraphs, images over text, low friction. Micro-interactions matter most.
- Dark and light themes (`theme: 'dark' | 'light' | 'auto'`), matching the protein sheet's look.
- Three to five signature moments:
  - body to lungs: one continuous camera dolly, about 700–900 ms, ease-out;
  - lungs to protein: a dive that crossfades into the protein canvas;
  - a three-step rail (Body · Lungs · Protein) with a sliding indicator, so the clinician can tap back out.
- Nothing loops and nothing spins on its own. Drag to rotate is fine.
- With reduced motion, use jump cuts.
- Esc closes and focus returns to the opener. Hit targets are 44 px or more, contrast 4.5:1 or more, and every canvas has an aria-label.
- A still-image fallback for when WebGL is missing.
- Build `journey-demo.html` with the four demo patients first, and get it looked at before polishing.

## Done means

- A demo page showing all four demo patients at 1440×900 and 390×844, dark and light.
- Screenshots that include a mid-zoom frame, the no-driver end state and the no-WebGL fallback.
- Zero console errors and zero network requests.
- A short note with the files and sizes, the model sources and licences, what each patient sees, and anything unverified.

## Demo patients

| Record | Driver |
|---|---|
| TCGA-93-A4JP | EGFR L861Q |
| TCGA-49-AAQV | EGFR exon 19 deletion |
| TCGA-86-7714 | BRAF V600E |
| TCGA-99-8033 | No driver found; KRAS and ALK negative, the rest not tested |
